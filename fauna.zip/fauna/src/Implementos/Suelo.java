/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Implementos;

/**
 *
 * @author 0
 */
public enum Suelo {
    TIERRA, ARENA, GRAVA, AGUA, AGUA_SALADA, AGUA_DULCE
}
